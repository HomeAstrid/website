<?php 
echo  (rand(0, 1) == 1) ? '0Nul gereturned': '1Een gereturned';
?>